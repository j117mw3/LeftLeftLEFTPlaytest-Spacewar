Left! Left! LEFT! - Spacewar v0.1.0

Requirements: Windows x64 playtest build 26172243; Steam running; each player uses the same build and package with a separate Steam account.

1. Close the game. Back up GameAssembly.dll and any existing steam_appid.txt outside the game folder.
2. The original DLL SHA-256 must be b81c064eabebbc0b30af66f9684df3ffbae5e8a515e76a813c95a5ca95158f2e.
3. Extract these files beside LeftLeftLEFT.exe, replacing GameAssembly.dll.
4. Launch LeftLeftLEFT.exe with Steam running. Create a lobby and invite your friend. No launch arguments are needed.

A two-player co-op session was reported successful. Recovery and progression tests remain unverified. Steam's disabled playtest Play button is not restored.

To uninstall, close the game, restore the DLL backup and restore the original steam_appid.txt or remove it if it was newly added.

The game-derived DLL is subject to the rights holder's terms. This is an unofficial project.
